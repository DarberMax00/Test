from tkinter import *

finestra = Tk()

tela = Canvas(finestra,width=500,height=500)
tela.pack()

class Auto:
    def __init__(self):

        global tela

        self.disegno2 = tela.create_rectangle(150,150,170,170,fill="blue")
        self.disegno = tela.create_oval(250,250,270,270,fill="red")
        self.direzione = "O"
        self.v = 1
        self.continua = True

        tela.focus_set()
        tela.bind("<Key>",self._tastiera)

    def _tastiera(self,event):

        if event.char=='m' or event.char=='M': self.v = self.v + 1
        if event.char=='n' or event.char=='N': self.v = self.v - 1
        if self.v>3:        self.v=3
        if self.v<0:        self.v=0

        if event.char=='w' or event.char=='W': self.direzione = "N"
        if event.char=='a' or event.char=='A': self.direzione = "E"
        if event.char=='s' or event.char=='S': self.direzione = "S"
        if event.char=='d' or event.char=='D': self.direzione = "O"

    def _avanza(self):
        if not self.continua: return
        global tela
        if self.direzione == "O": tela.move(self.disegno,self.v,0)
        if self.direzione == "E": tela.move(self.disegno,-self.v,0)
        if self.direzione == "N": tela.move(self.disegno,0,-self.v)
        if self.direzione == "S": tela.move(self.disegno,0,self.v)

        c = tela.coords(self.disegno)

        if c[0] > 500:
            c[0]=0
            c[2]=20

        if c[1] > 500:
            c[1] = 0
            c[3] = 20

        if c[2] < 0:
            c[0]=480
            c[2]=500

        if c[3] < 0:
            c[1] = 480
            c[3] = 500

        tela.coords(self.disegno,c)

        d = tela.coords(self.disegno2)

        if c[0]>d[0] and c[0]<d[2] and c[2]>d[1] and c[2]<d[3]:
            tela.coords(self.disegno,[250,250,270,270])

        if c[1]>d[1] and c[1]<d[3] and (c[3]>d[1] and c[3]<d[3]):
            tela.coords(self.disegno,[250,250,270,270])

        tela.after(40,self.inizia)

    def inizia(self):
        self._avanza()

auto = Auto()
auto.inizia()

finestra.mainloop()
